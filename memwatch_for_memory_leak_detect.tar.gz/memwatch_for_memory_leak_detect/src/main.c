
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>

#include "memwatch.h" //包含memwatch提供的头文件

static void signal_handler(int sign_no)
{
    printf("Capture signal no: %d\n", sign_no); 
	
	exit(-1);
}

int memory_leak_test(void)
{
	char *p, *p1, *p2=NULL;
	
	p = malloc(100); //申请空间
	if (p) {
		strcpy(p, "123456");
	}
	
	p1 = malloc(5); //申请空间
	if (p1) {
		strcpy(p1, "123456");
	}
	
	//free(p); //使用完故意不释放
	//free(p1); //使用完故意不释放
	
	*p2 = '5'; //访问空指针，导致segment default (core dump)，memwatch并不能坚持出来
	
	return 0;
}

int main(int arc, const char *argv[])
{
	signal(SIGSEGV, signal_handler); 
	
	printf("This is a sample for memwatch to detect memory leak !!!\n");
	
	memory_leak_test();
	
	return 0;
}